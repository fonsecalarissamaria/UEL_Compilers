int f () { return 0; }

void
test ()
{
    int j = { f() };
}
