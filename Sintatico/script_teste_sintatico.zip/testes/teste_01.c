int
/*
 *  /* comentario de bloco
 *  /* comentario de bloco
 *
*/
mod (int a, int b)

{
  return (a % b);
}

int
main ()
{
  mod (1, 2);
  exit (0);
}
