void f ()
{
  {{;}}
  return (1);
}
