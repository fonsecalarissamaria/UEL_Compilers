void f(int j){return (j++>0);}
int main(){if(f((~0)>>1)){abort();}exit(0);}
