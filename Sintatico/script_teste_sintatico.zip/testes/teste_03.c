int B,Q;
void f(){int s;for(s=0;s<=1;s++){while(s){if(2){B++;}if(4){Q--;}}}}
