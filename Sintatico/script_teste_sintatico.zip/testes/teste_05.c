int f () { return (0); }

void
test ()
{
    int j =  f() ;;
}

/*
  
   if (@)
   {
   	i;;;;;
   }
 
  /* comentario 
   
   for while if



*/
 





